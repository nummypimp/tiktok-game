const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const { TikTokConnectionWrapper, getGlobalConnectionCount } = require('./connectionWrapper');
const OBSWebSocket = require('obs-websocket-js').default;
const path = require('path');
const app = express();
const server = http.createServer(app);
const io = new Server(server);
let tiktokConnectionWrapper;
let uniqueId = '@pimprapa';
let options = {};

try {
  tiktokConnectionWrapper = new TikTokConnectionWrapper(uniqueId, options, true);
  tiktokConnectionWrapper.connect();
  console.log('✅ เชื่อมต่อกับ TikTok LIVE');
} catch (err) {
  console.error('❌ เชื่อม TikTok ไม่สำเร็จ:', err);
  return;
}
const obs = new OBSWebSocket();

let registeredUsers = {};
let round1Passed = {};
let round2Choice = {};
let currentRound = 0;
let game2Round = 0;
let allowRegister = true;

// Serve frontend build
app.use(express.static(path.join(__dirname, './tiktok-live-game/build')));
app.get(/^\/(?!admin).*/, (req, res) => {
  res.sendFile(path.join(__dirname, './tiktok-live-game/build/index.html'));
});
async function connectOBS() {
  try {
    await obs.connect('ws://localhost:4455');
    console.log('✅ เชื่อมต่อ OBS สำเร็จ');
  } catch (err) {
    console.error('❌ OBS connect error:', err);
  }
}
connectOBS();

// TikTok Events
tiktokConnectionWrapper.connection.on('like', data => {
  updateUser(data.user.uniqueId, 'like', data.likeCount, data)
});
tiktokConnectionWrapper.connection.on('share', data => {
  updateUser(data.user.uniqueId, 'share', 1, data)
});
tiktokConnectionWrapper.connection.on('gift', data => {
  updateUser(data.user.uniqueId, 'gift', data.giftDiamondCount, data)
});
tiktokConnectionWrapper.connection.on('chat', data => {
  updateUser(data.user.uniqueId, 'chat', 1, data)
  handleChat(data)
});

function updateUser(id, type, count, data) {
  if (!registeredUsers[id]) registeredUsers[id] = {
    like: 0,
    share: 0,
    gift: 0,
    emoji: 0,
    registered: false,
    chat: 0
  };
  registeredUsers[id][type] += count;
  checkRegistration(id, data);
}

function checkRegistration(id, data) {
  if (!allowRegister || registeredUsers[id].registered) return;
  const u = registeredUsers[id];
  if (u.like >= 10 || u.share >= 30 || u.gift >= 30) {
    u.registered = true;
    u.gift = 0;
    io.emit('user-registered', {
      id,
      nickname: data.user.nickname,
      avatar: data.user.profilePicture.urls[0]
    });
  }
}

function handleChat(data) {
  const id = data.user.uniqueId;
  const msg = data.comment.trim();
  if (registeredUsers[id].registered && !registeredUsers[id].round1Passed) {
    const emojiCount = (msg.match(/\p{Emoji}/gu) || []).length;
    if (emojiCount >= 1) registeredUsers[id].emoji += 1;
    if (registeredUsers[id].emoji >= 1 || registeredUsers[id].gift >= 30) {
      registeredUsers[id].round1Passed = true;
      registeredUsers[id].gift = 0;
      round1Passed[id] = {
        id,
        nickname: data.user.nickname,
        avatar: data.user.profilePicture.urls[0]
      };
      io.emit('round1-winner', round1Passed[id]);
    }
  }
  if (currentRound === 2 && round1Passed[id]) {
    if (/ซ้าย|กลาง|ขวา/.test(msg)) {
      round2Choice[id] = msg;
    }
  }
}

// Admin Routes
app.post('/admin/start-register', (req, res) => {
  allowRegister = true;
  registeredUsers = {};
  io.emit('register-start');
  res.sendStatus(200);
});

app.post('/admin/stop-register', (req, res) => {
  allowRegister = false;
  io.emit('register-end', Object.keys(registeredUsers).filter(id => registeredUsers[id].registered));
  res.sendStatus(200);
});

app.post('/admin/start-game-1', (req, res) => {
  currentRound = 1;
  round1Passed = {};
  io.emit('game-1-start');
  res.sendStatus(200);
});

app.post('/admin/start-game-2', (req, res) => {
  currentRound = 2;
  round2Choice = {};
  game2Round = 0;
  io.emit('game-2-start');
  res.sendStatus(200);
});

app.post('/admin/finish-game-2-round', (req, res) => {
  game2Round++;
  const doors = ['ซ้าย', 'กลาง', 'ขว'];
  const eliminated = doors[Math.floor(Math.random() * 3)];
  const survivors = Object.keys(round2Choice).filter(id => round2Choice[id] !== eliminated);
  round1Passed = Object.fromEntries(Object.entries(round1Passed).filter(([id]) => survivors.includes(id)));
  io.emit('game-2-result', {
    round: game2Round,
    eliminated,
    survivors
  });

  if (game2Round >= 3) {
    io.emit('game-2-finish', Object.values(round1Passed));
    currentRound = 0;
  }

  res.sendStatus(200);
});

app.post('/admin/reset-game', (req, res) => {
  registeredUsers = {};
  round1Passed = {};
  round2Choice = {};
  currentRound = 0;
  game2Round = 0;
  io.emit('game-reset');
  res.sendStatus(200);
});

server.listen(3000, () => console.log('Server started at http://localhost:3000'));
